package com.atidev.basithesapmakinesi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    /// tasarımımızda yer alan kısımları global sınıfa ekledik, bu bize kolaylık sağlıyor.
    EditText number1Text;
    EditText number2Text;
    TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /// kutuları çağırdık. App çalıştığı anda karşımıza çıkacak.

        number1Text = findViewById(R.id.number1text);
        number2Text = findViewById(R.id.number2text);
        resultText = findViewById(R.id.resultText);



    }

    // bilerek kullanıcının ekranını sayı klavyesine çevirmedim. Sonraki projelerde olası benzer bir hata olmaması ve tecrübe olması adına "try-catch" blokları ile bir çalışma sağladım.
    // 0'a bölünme ya da mod alma sırasında uygulama çöküyordu. Bunu "if" ile engelledim.
    public void sum(View view) {
        try {
            int number1 = Integer.parseInt(number1Text.getText().toString());
            int number2 = Integer.parseInt(number2Text.getText().toString());

            int result = number1 + number2;
            resultText.setText("Result: " + result);
        } catch (NumberFormatException e) {
            resultText.setText("Sadece sayı");
        }
    }

    public void deduct(View view) {
        try {
            int number1 = Integer.parseInt(number1Text.getText().toString());
            int number2 = Integer.parseInt(number2Text.getText().toString());

            int result = number1 - number2;
            resultText.setText("Result: " + result);
        } catch (NumberFormatException e) {
            resultText.setText("Sadece sayı");
        }
    }

    public void multiply(View view) {
        try {
            int number1 = Integer.parseInt(number1Text.getText().toString());
            int number2 = Integer.parseInt(number2Text.getText().toString());

            int result = number1 * number2;
            resultText.setText("Result: " + result);
        } catch (NumberFormatException e) {
            resultText.setText("Sadece sayı");
        }
    }

    public void divide(View view) {
        try {
            int number1 = Integer.parseInt(number1Text.getText().toString());
            int number2 = Integer.parseInt(number2Text.getText().toString());

            if (number2 == 0) {
                resultText.setText("Sonuç Yok");
            } else {
                int result = number1 / number2;
                resultText.setText("Result: " + result);
            }
        } catch (NumberFormatException e) {
            resultText.setText("Sadece sayı");
        }
    }

    public void modd(View view) {
        try {
            int number1 = Integer.parseInt(number1Text.getText().toString());
            int number2 = Integer.parseInt(number2Text.getText().toString());

            if (number2 == 0) {
                resultText.setText("Sonuç yok");
            } else {
                int result = number1 % number2;
                resultText.setText("Result: " + result);
            }
        } catch (NumberFormatException e) {
            resultText.setText("Sadece sayı");
        }
    }

}